import express from 'express';
import multer from 'multer';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 }
});

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const logs = [];
function log(message, type='info') {
  const row = { time: new Date().toISOString(), type, message };
  logs.push(row);
  if (logs.length > 250) logs.shift();
  console.log(`[${type}] ${message}`);
  return row;
}

app.get('/api/health', (_req, res) => res.json({ ok: true, app: 'PHBuilderman Roblox Publisher' }));
app.get('/api/logs', (_req, res) => res.json(logs));

// Official Roblox Open Cloud place publishing endpoint.
// The API key stays on the server and is NEVER sent to the browser.
app.post('/api/publish', upload.single('placeFile'), async (req, res) => {
  try {
    const { universeId, placeId, versionType = 'Published', apiKey } = req.body;
    if (!universeId || !placeId) return res.status(400).json({ error: 'Universe ID and Place ID are required.' });
    if (!apiKey) return res.status(400).json({ error: 'API key is required for this server request.' });
    if (!req.file) return res.status(400).json({ error: 'Upload an .rbxl or .rbxlx file.' });

    const contentType = req.file.originalname.toLowerCase().endsWith('.rbxlx')
      ? 'application/xml'
      : 'application/octet-stream';

    const url = `https://apis.roblox.com/universes/v1/${encodeURIComponent(universeId)}/places/${encodeURIComponent(placeId)}/versions?versionType=${encodeURIComponent(versionType)}`;
    log(`Publishing ${req.file.originalname} to Universe ${universeId}, Place ${placeId}...`);

    const r = await fetch(url, {
      method: 'POST',
      headers: { 'x-api-key': apiKey, 'content-type': contentType },
      body: req.file.buffer
    });

    const text = await r.text();
    let body;
    try { body = JSON.parse(text); } catch { body = { raw: text }; }

    if (!r.ok) {
      log(`Roblox returned HTTP ${r.status}.`, 'error');
      return res.status(r.status).json({ error: body?.message || body?.error || body?.raw || 'Roblox rejected the request.', details: body });
    }
    log(`Publish succeeded. Version: ${body.versionNumber ?? 'unknown'}`, 'success');
    res.json({ ok: true, versionNumber: body.versionNumber, response: body });
  } catch (err) {
    log(err.message, 'error');
    res.status(500).json({ error: 'Server error.', details: err.message });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => log(`PHBuilderman Publisher listening on http://localhost:${port}`));
