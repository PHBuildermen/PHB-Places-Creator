# PHBuilderman Roblox Publisher

A simple, original arcade/pixel-style web interface for publishing an existing Roblox place through the official Roblox Open Cloud Place Publishing API.

**Credit:** Made by **PHBuilderman**  
**Not affiliated with Roblox or Axo.**

## Why this version does not ask for `.ROBLOSECURITY`
Roblox currently recommends API-key or OAuth authentication for Open Cloud. Cookie-based legacy APIs are not recommended for production applications. This project keeps the Open Cloud API key on the server and uses the official place publishing endpoint.

## What it can do
- Publish `.rbxl` and `.rbxlx` files to an existing Universe/Place.
- Show the returned published version number.
- Keep a small server-side activity log.
- Work as a normal Node/Express app and can be deployed to a server platform.

## Setup

1. Install Node.js 20+.
2. Run:

```bash
npm install
npm start
```

3. Open `http://localhost:3000`.
4. In Roblox Creator Dashboard, create an Open Cloud API key with the `universe-places` **Write** permission for the target experience.
5. Enter the Universe ID, Place ID, API key, and `.rbxl`/`.rbxlx` file.

## Important deployment note
A GitHub Pages site is static and should **not** contain a Roblox API key. Deploy the Node server to a backend host (for example a container/server service) and point your domain to it. For a public production tool, use environment-managed secrets instead of asking users to paste API keys.

## About creating a brand-new Universe
The current official public Open Cloud documentation documents publishing versions to existing places. It does not document a stable public browser endpoint for creating a brand-new Universe. The safe version of this project therefore handles **place publishing**, not automated universe creation.

## Suggested future features
- Drag-and-drop place file upload.
- Recent publishes table.
- File size/type validation.
- Multiple project profiles.
- GitHub Actions workflow for automated publishing.
