const tabs = document.querySelectorAll('.tab');
const panels = document.querySelectorAll('.tab-panel');
for (const tab of tabs) tab.addEventListener('click', () => {
  tabs.forEach(t => t.classList.remove('active'));
  panels.forEach(p => p.classList.remove('active'));
  tab.classList.add('active');
  document.getElementById(tab.dataset.tab).classList.add('active');
  if (tab.dataset.tab === 'logs') loadLogs();
});

const fileInput = document.getElementById('placeFile');
fileInput.addEventListener('change', () => {
  const f = fileInput.files[0];
  document.getElementById('filebox').textContent = f ? `${f.name} • ${(f.size/1024/1024).toFixed(2)} MB` : 'NO FILE SELECTED';
});

function setProgress(p, text){document.querySelector('#progress span').style.width=p+'%';document.getElementById('progressText').textContent=text}

const form = document.getElementById('publishForm');
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const button = form.querySelector('button[type=submit]');
  button.disabled = true;
  setProgress(10,'UPLOADING...');
  try {
    const fd = new FormData(form);
    const r = await fetch('/api/publish', {method:'POST',body:fd});
    setProgress(65,'ROBLOX REQUEST...');
    const data = await r.json().catch(()=>({error:'Invalid server response'}));
    if(!r.ok) throw new Error(data.error || 'Publish failed');
    setProgress(100,`SUCCESS • VERSION ${data.versionNumber ?? '?'}`);
  } catch(err){
    setProgress(100,'ERROR');
    alert(err.message);
  } finally { button.disabled=false; }
});

document.getElementById('refreshLogs').addEventListener('click', loadLogs);
async function loadLogs(){
  const box=document.getElementById('console');
  try{
    const r=await fetch('/api/logs'); const rows=await r.json();
    box.innerHTML = rows.length ? rows.map(x=>`<div class="log-line log-${x.type}">[${new Date(x.time).toLocaleTimeString()}] ${escapeHtml(x.message)}</div>`).join('') : 'NO LOGS YET';
    box.scrollTop=box.scrollHeight;
  }catch{box.textContent='Could not load logs.'}
}
function escapeHtml(s){return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')}
